# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'e0bb4164ecd595d268315175b0f85018fc811f76ae1f2f4a4307ee7390f0e37e6ffdc9501073dac16189d9d41438226563960b7ae2f8567beecb814c638b398c'